-Before launching make sure that python is added to PATH (This was done during python installation).
-If python was not added to path then uninstall and reinstall python and make sure to check "Add python to PATH" during installation.

-Open command prompt and copy and paste these following lines in order, one by one.
pip install Pillow
pip install pyttsx3
pip install pipwin
pipwin install PyAudio
pip install SpeechRecognition
pip install pygame
pip install pywin32